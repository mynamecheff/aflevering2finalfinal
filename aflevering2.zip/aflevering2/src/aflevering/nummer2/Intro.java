package aflevering.nummer2;

public class Intro {
    public void introduction() {
        /*this is the file that introduces the user to the program.
        You could easily just write the println statement in the program,
         but this is more fun! */
        System.out.println("Welcome to our program");
    }
}
